---
name: citation-readiness-audit-kg
description: >
  Audit whether content contains extractable atomic claims LLMs would cite and
  whether those claims are unique to this source. Maps to Proof of Importance
  framework signals. Uses KeywordGraph optimize_text_structure for bias/coherence
  scoring on top of atomic claim and structural analysis. Use when the user wants
  to check citation readiness, audit LLM citability, assess AI extractability,
  validate content against PoI signals, test whether a page would get cited by
  ChatGPT or Perplexity, or says things like "is this citable", "will AI cite
  this", "citation readiness check", "PoI audit", "extractability check",
  "audit this for AI citation", or "/citation-readiness-audit-kg". Also trigger
  as a final quality gate before publishing content targeting AI visibility.
---

# Citation Readiness Audit (KeywordGraph)

Audit whether content contains extractable atomic claims an LLM would cite, whether those claims are unique to this source, and whether the content's structural coherence supports clean cluster-level extraction. Connects directly to the Proof of Importance framework.

> AI retrieval systems extract at the sentence level, not the page level. A 3,000-word article with zero extractable atomic claims gets zero citations. A 500-word page with five clean, self-contained factual statements can dominate AI answers. Structural coherence at the cluster level determines whether those atomic claims sit in retrievable context or get lost in noise.

## When to use

- Final pre-publish check for any content targeting AI search visibility
- After writing thought leadership articles, framework pages, or methodology docs
- When auditing existing pages that should be getting AI citations but are not
- To compare citation readiness of your content vs. competitor content
- As a training tool to improve writing habits for AI-era content

## Tools Required

| Tool | Use Case | Key Functions |
|---|---|---|
| **[Firecrawl](https://firecrawl.link/jack-boutchard)** 10% off | Scrape content from URLs and competitor pages in markdown for atomic claim extraction and uniqueness benchmarking | `firecrawl_scrape` |
| **[KeywordGraph](https://keywordgraph.com/signup?exaltgrowth)** · [MCP Server](https://exaltgrowth.keywordgraph.com) | Analyze content bias and coherence via knowledge graph to score structural retrievability of atomic claims | `optimize_text_structure` |

## Input

Ask the user for:

1. **Content to audit** (required): Pasted text, file path, or web URL
2. **Target queries** (optional): 3-5 questions this content should answer in AI platforms
3. **Competitor URLs** (optional): 1-3 competitor pages to benchmark against

## Proof of Importance signal mapping

| PoI Signal | What the Audit Checks |
|---|---|
| **Semantic Relevance** | Does the content directly answer the target queries? |
| **Evidence Density** | Specific data, stats, named frameworks, citations? |
| **Structural Accessibility** | Chunked, headed, formatted for extraction? |
| **Recency** | Dated? References current data? |
| **Corroboration** | Cites or references external authoritative sources? |
| **Structural Coherence** (NEW) | Is the content focused/diversified, or biased/dispersed? |

Source Authority and Entity Relationships are page/domain-level signals. The skill notes their importance but does not score them.

## Workflow

### Step 1: Content extraction

If a URL, scrape via Firecrawl:

```
firecrawl-mcp:firecrawl_scrape
  url: [URL]
  formats: ["markdown"]
```

### Step 2: Atomic claim extraction

Identify every statement that could function as a standalone cited fact. An atomic claim must be:

1. **Self-contained**: Understandable without context
2. **Declarative**: States a fact, definition, statistic, or causal relationship
3. **Under 20 words**: LLMs extract concise statements
4. **Specific**: Concrete noun, number, or named entity

For each atomic claim found, record:

- Exact sentence
- Location (section heading)
- Type: Definition, Statistic, Process Step, Causal Claim, Framework Element, Comparison
- Whether it contains a named entity, number, or proprietary term

Also flag **near-miss claims**: sentences containing a citable fact but failing one criterion. These are highest-leverage editing targets.

### Step 3: Uniqueness check

For each atomic claim, check if the same fact appears in competing sources.

If target queries provided:

```
web_search: "[target query]"
```

If competitor URLs provided:

```
firecrawl-mcp:firecrawl_scrape
  url: [competitor URL]
  formats: ["markdown"]
```

Classify each claim:

| Classification | Definition |
|---|---|
| **Unique** | Specific claim does not appear in top results or competitor pages |
| **Better-stated** | Exists elsewhere but this version is more concise, specific, extractable |
| **Commodity** | Identical claim appears in 3+ competing sources |

### Step 4: Structural accessibility audit

| Element | Present? | Score |
|---|---|---|
| H2/H3 hierarchy matching question patterns | Y/N | /10 |
| Definition blocks for key terms | Y/N | /10 |
| Comparison tables for frameworks, tools, approaches | Y/N | /10 |
| FAQ section with questions matching target queries | Y/N | /10 |
| Numbered steps for process-oriented content | Y/N | /10 |
| Front-loaded answers (key claim in first 35%) | Y/N | /10 |
| Schema markup indicators (JSON-LD, FAQ, HowTo) | Y/N | /10 |
| Short paragraphs (majority under 3 sentences) | Y/N | /10 |
| Source list or references visible on page | Y/N | /10 |
| datePublished / dateModified present | Y/N | /10 |

Total Structural Score: /100

### Step 5: Evidence density audit

| Evidence Type | Count | Examples Found |
|---|---|---|
| Named frameworks or methodologies | | |
| Specific statistics with sources | | |
| Named case studies or examples | | |
| External citations (linked sources) | | |
| Proprietary data or original research | | |
| Expert quotes with attribution | | |
| Comparison data (X vs. Y with specifics) | | |

Calculate Evidence Density Ratio:

```
Evidence Density = Evidence elements / Total paragraphs
```

| Ratio | Rating |
|---|---|
| > 0.5 | High density |
| 0.25 - 0.5 | Moderate density |
| < 0.25 | Low density |

### Step 6: Structural coherence audit (KeywordGraph)

This step catches a failure mode atomic claims alone cannot diagnose: content that has good claims but poor cluster structure, where claims sit in topical isolation or get lost in unfocused prose.

```
KeywordGraph:optimize_text_structure
  context: "Analyzing content structural coherence via bias and modularity scoring for citation readiness audit quality gate."
  text: [content]
  responseType: "response"
```

Capture from the response:

- `diversity_stats.diversity_score`: "focused" / "diversified" / "biased" / "dispersed"
- `diversity_stats.modularity_score`: "low" / "medium" / "high"
- `mainTopicalClusters`: cluster structure
- `topicsToDevelop`: weakly developed bridges
- `suggestions`: structural recommendations

Map the diversity score to a structural coherence rating:

| Diversity Score | Modularity Score | Coherence Rating | Interpretation |
|---|---|---|---|
| Focused or Diversified | High or Medium | Strong | Content has clear clusters with healthy bridges. Atomic claims sit in retrievable context. |
| Focused | Low | Moderate | Content has clusters but weak connective tissue. Claims may be retrieved without enough surrounding context. |
| Biased | Any | Weak | Content is over-concentrated on one cluster. Other claims may be missed by retrievers. |
| Dispersed | Any | Weak | Content lacks clear cluster structure. Claims are scattered and individually under-supported. |

Capture specific structural improvements suggested by `topicsToDevelop`. These are bridges the content should strengthen.

### Step 7: Query-response alignment

For each target query (provided or inferred):

1. Does the content contain a direct, extractable answer?
2. Is the answer in the first 35% of the page?
3. Is the answer atomic (under 20 words, self-contained)?
4. Would the answer make sense extracted without surrounding text?

Score each query on a 4-point scale:

- **4/4**: Direct atomic answer, front-loaded, self-contained
- **3/4**: Answer exists but buried, too long, or context-dependent
- **2/4**: Partial answer
- **1/4**: Tangentially related
- **0/4**: No answer found

### Step 8: Generate report

```markdown
## Citation Readiness Audit: [Content Title or URL]

**Date audited**: [current date]
**Target queries**: [list]

### Overall Citation Readiness: [X]/100

| Component | Score | Weight |
|---|---|---|
| Atomic Claim Density | [X]/100 | 25% |
| Claim Uniqueness | [X]/100 | 20% |
| Structural Accessibility | [X]/100 | 20% |
| Structural Coherence | [X]/100 | 15% |
| Evidence Density | [X]/100 | 10% |
| Query-Response Alignment | [X]/100 | 10% |

### Atomic Claims Found: [N]

#### Unique Claims (highest citation potential)

| Claim | Section | Type |
|---|---|---|

#### Better-Stated Claims (competitive advantage)

| Claim | Section | Competitor Version |
|---|---|---|

#### Commodity Claims (low citation value)

| Claim | Section | Also in |
|---|---|---|

### Near-Miss Claims (highest-leverage edits)

| Current Sentence | Problem | Suggested Rewrite |
|---|---|---|

### Structural Accessibility: [X]/100

[Breakdown table from Step 4]

### Structural Coherence: [Rating]

- **Diversity Score**: [focused / diversified / biased / dispersed]
- **Modularity Score**: [low / medium / high]
- **Cluster count**: [N]
- **Implications for retrieval**: [interpretation]

**Topics to Develop (bridge strengthening)**:

| Bridge | Current State | Recommended Action |
|---|---|---|

### Evidence Density: [ratio] — [rating]

[Breakdown table from Step 5]

### Query-Response Alignment

| Target Query | Score | Answer Location | Issue |
|---|---|---|---|

### Priority Edits (ranked by citation impact)

1. [Most impactful edit]
2. ...

### PoI Signal Summary

| Signal | Status | Action Needed |
|---|---|---|
| Semantic Relevance | [Strong/Moderate/Weak] | |
| Evidence Density | [Strong/Moderate/Weak] | |
| Structural Accessibility | [Strong/Moderate/Weak] | |
| Structural Coherence | [Strong/Moderate/Weak] | |
| Recency | [Strong/Moderate/Weak] | |
| Corroboration | [Strong/Moderate/Weak] | |
```

## Output destination

Present inline in chat.

## Tool reference

| Tool | Step | Purpose |
|---|---|---|
| `firecrawl_scrape` | 1, 3 | Content and competitor extraction |
| `web_search` | 3 | Uniqueness check against SERP |
| `KeywordGraph:optimize_text_structure` | 6 | Bias/coherence cluster analysis |

## Edge cases

- **Content with no target queries**: Infer 3-5 from H2 headings and key topics. Flag as inferred.
- **Competitor content is gated**: Skip uniqueness comparison for those sources.
- **Very long content** (5,000+ words): Focus atomic claim extraction on first 35% and FAQ/conclusion sections.
- **Content already published and underperforming**: Audit becomes gap analysis rather than pre-publish check.
- **Structural coherence is biased**: When `diversity_score` is "biased", the content is over-concentrated. This may be acceptable for narrow-scope content but is a warning for broad topical pages.
- **KeywordGraph unavailable**: Skip Step 6. Note that structural coherence cannot be scored. Reduce overall readiness score weighting accordingly.
