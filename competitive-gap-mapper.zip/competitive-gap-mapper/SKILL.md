---
name: competitive-gap-mapper-kg
description: >
  Map relation-level positioning gaps between a brand URL and 3-5 competitor URLs using
  KeywordGraph. Builds a merged competitor corpus graph, runs bidirectional
  difference_between_texts to surface shared positioning (commodity claims), competitor-owned
  territory (gaps), and client-owned territory (defensive assets). Output is an entity-level
  differential map for positioning strategy, content roadmaps, and category fit assessments.
  Use when asked to map competitive gaps, compare brands at entity level, identify positioning
  white space, run a positioning audit, or says "map gaps between [client] and [competitors]",
  "positioning audit", "entity-level competitive analysis", "what do competitors say that we
  don't", "competitive gap map", or "/competitive-gap-mapper-kg". For single page refresh use
  article-updater. For article-vs-SERP info gain use information-gain-scorer.
---

# Competitive Gap Mapper (KeywordGraph)

Compare a brand URL against N competitor URLs at the relation level. Build a merged competitor corpus graph, then run bidirectional difference analysis to surface positioning gaps and defensive assets. Output is an entity-level differential map.

> Keyword-level competitive analysis misses positioning structure. Two brands can target the same keywords while making entirely different claims. Relation-level analysis catches what brands actually assert: their entity relationships, cluster ownership, and conceptual territory. This skill operates at that level.

## When to use

- Positioning audits before a category repositioning
- Content roadmap planning grounded in white space evidence
- Category fit assessments when a brand is unsure where to stake claim
- New market entry analysis (contested vs open territory)
- Quarterly competitive reviews focused on positioning drift
- Pre-rebrand exercises to map current vs target positioning

## Tools Required

| Tool | Use Case | Key Functions |
|---|---|---|
| **[KeywordGraph](https://keywordgraph.com/signup?exaltgrowth)** · [MCP Server](https://exaltgrowth.keywordgraph.com) | Relation-level graph analysis, overlap detection, difference extraction, persistent graph visualization | `merged_graph_from_texts`, `analyze_text`, `overlap_between_texts`, `difference_between_texts`, `create_knowledge_graph` |
| **[Firecrawl](https://firecrawl.link/jack-boutchard)** 10% off | Pre-scrape all URLs before KeywordGraph analysis. Handles JS rendering and paywalls. | `firecrawl_scrape` |
| **Visualizer** (built-in) | Inline competitive territory diagram rendered in chat | `visualize:show_widget` |

## Input

Collect from the user:

1. **Brand URL** (required): The brand's primary positioning URL. Usually homepage. May be a solutions page if targeting a specific category.
2. **Competitor URLs** (required): 3-5 competitor URLs. Match URL type to the brand URL (homepages vs homepages, solutions vs solutions).
3. **Analysis scope** (optional, default: "positioning"): One of:
   - `positioning`: Homepage and primary positioning pages
   - `solution`: Specific solution or category pages
   - `content`: Blog or resource hub comparison
4. **Graph visuals** (optional, default: no): Ask "Do you want to generate graph visuals of the competitive gap?" If yes, the skill will:
   - Save persistent named graphs to KeywordGraph for interactive exploration
   - Render an inline territory diagram in chat via the Visualizer

The brand URL and competitor URLs can be provided as web URLs, pasted text content, or file paths to scraped content.

If the user provides only a brand URL, ask for competitor URLs before proceeding.

## Workflow

### Step 1: Scrape all URLs with Firecrawl

Scrape every URL (brand + all competitors) with Firecrawl before passing anything to KeywordGraph. This prevents KeywordGraph from fetching URLs directly, which causes timeouts on JS-heavy or slow-loading sites.

```
firecrawl-mcp:firecrawl_scrape
  url: [URL]
  formats: ["markdown"]
  onlyMainContent: true
```

Run this for each URL. Store the returned markdown content. These scraped texts are passed to all subsequent KeywordGraph calls via the `text` parameter instead of `url`.

After scraping, validate:

- Flag any URL returning under 500 words. Thin pages produce weak graphs.
- If a URL returns blocked content or paywalls, note it and proceed with remaining URLs.
- Minimum viable competitor count is 3. Below that, the merged corpus baseline is unreliable.

### Step 2: Build the merged competitor corpus

Use `merged_graph_from_texts` to build a single combined positioning graph from all competitor content scraped in Step 1. Always pass content via the `text` parameter, never via `url`.

```
KeywordGraph:merged_graph_from_texts
  context: "Building merged competitor corpus graph from multiple competitor URLs to establish field positioning baseline."
  contexts:
    - { text: "[scraped content from competitor 1]" }
    - { text: "[scraped content from competitor 2]" }
    - { text: "[scraped content from competitor 3]" }
    - { text: "[scraped content from competitor 4]" }
    - { text: "[scraped content from competitor 5]" }
  includeStatements: true
```

From the response capture:

- `mainTopicalClusters`: positioning themes the competitor field owns collectively
- `topRelations`: high-frequency relations across the field
- `mainConcepts`: combined entity inventory of competitor positioning
- `contentGaps`: structural gaps in competitor positioning (unclaimed bridges)
- `graphSummary`: AI-generated summary of the competitor positioning landscape
- `statements`: raw text statements for graph persistence

Save this as the **competitor field baseline**.

If the user requested graph visuals, persist the merged corpus as a named KeywordGraph graph:

```
KeywordGraph:create_knowledge_graph
  context: "Persisting merged competitor corpus as named graph for interactive visual exploration on KeywordGraph."
  graphName: "gap-map-competitors-[brand-slug]-[date]"
  text: "[concatenated statements from merged_graph_from_texts response]"
```

Capture the returned graph URL. This link goes in the final output.

If `merged_graph_from_texts` times out (large graphs can stall), fall back to individual `analyze_text` calls per scraped text. Manually aggregate clusters and relations. Note the degradation.

### Step 3: Build the brand graph

```
KeywordGraph:analyze_text
  context: "Analyzing brand URL to extract entity-level positioning graph for bidirectional competitive comparison."
  text: "[scraped content from brand URL]"
  includeGraph: true
  modifyAnalyzedText: "extractEntitiesOnly"
```

Capture:

- Brand topical clusters
- Brand top relations
- Brand main concepts
- Brand structural gaps

This is the **brand positioning baseline**.

If the user requested graph visuals, persist the brand graph:

```
KeywordGraph:create_knowledge_graph
  context: "Persisting brand positioning graph as named graph for interactive visual exploration on KeywordGraph."
  graphName: "gap-map-brand-[brand-slug]-[date]"
  text: "[scraped content from brand URL]"
```

Capture the returned graph URL. This link goes in the final output.

### Step 4: Surface shared positioning territory

Run overlap analysis to find what the brand and the competitor field share.

```
KeywordGraph:overlap_between_texts
  context: "Extracting shared entity relations between brand and competitor field to identify commodity positioning claims."
  contexts:
    - { text: "[scraped content from brand URL]" }
    - { text: "[scraped content from competitor 1]" }
    - { text: "[scraped content from competitor 2]" }
    - { text: "[scraped content from competitor 3]" }
    - { text: "[scraped content from competitor 4]" }
    - { text: "[scraped content from competitor 5]" }
  includeStatements: true
```

The response surfaces relations and clusters appearing across both the brand and competitors. These are **commodity claims**: table stakes for category coverage, zero differentiation.

For each shared cluster, record:

- Cluster name
- Representative relations
- Frequency across the corpus

### Step 5: Surface competitor-owned territory (brand gaps)

Run difference analysis from the brand perspective.

```
KeywordGraph:difference_between_texts
  context: "Finding entity relations present in competitor field but absent from brand positioning to identify coverage gaps."
  contexts:
    - { text: "[scraped content from brand URL]" }
    - { text: "[scraped content from competitor 1]" }
    - { text: "[scraped content from competitor 2]" }
    - { text: "[scraped content from competitor 3]" }
    - { text: "[scraped content from competitor 4]" }
    - { text: "[scraped content from competitor 5]" }
  includeStatements: true
```

The first context is the brand. Subsequent contexts are competitors. The response surfaces relations present in the competitor field but absent from the brand.

For each gap cluster, assess:

- Is this territory worth claiming? (Relevant to ICP, brand, capability)
- Is this territory worth ignoring? (Off-brand, low-value, out of scope)
- Is this territory ambiguous? (Surface for discussion)

The skill provides the mapping. The user makes the strategic call.

### Step 6: Surface brand-owned territory (defensive assets)

Invert the order to find what the brand has that competitors do not.

Loop through each competitor individually. `difference_between_texts` interprets the first context as the focal point.

```
KeywordGraph:difference_between_texts
  context: "Inverting comparison to find brand-exclusive entity relations absent from this competitor's positioning."
  contexts:
    - { text: "[scraped content from competitor 1]" }
    - { text: "[scraped content from brand URL]" }
  includeStatements: true
```

Repeat for each competitor. Aggregate relations consistently absent from all competitors but present in the brand.

These are **defensive positioning assets**: unique territory the brand owns. Recommendations:

- Reinforce in copy and content
- Build entity graph corroboration around them
- Use as differentiation hooks in sales and marketing

### Step 7: Identify field-level structural gaps (unclaimed by anyone)

The merged competitor corpus from Step 2 also surfaced `contentGaps`: structural gaps in the competitor field itself. Clusters or bridges that competitors collectively underdevelop.

Cross-reference against the brand graph:

- **Unclaimed by anyone**: Gaps in the competitor field AND absent from the brand. White space opportunities. First brand to claim them owns the territory.
- **Brand partially claims**: Gaps in the competitor field that the brand touches but does not own. Opportunity to deepen.

### Step 8: Render competitive territory visualization (if requested)

Skip this step if the user did not request graph visuals.

Build an inline network diagram using `visualize:show_widget` to give the user an at-a-glance view of the competitive landscape. Call `visualize:read_me` with module `diagram` before rendering.

Use cluster and territory data from Steps 4-7 to construct an SVG:

- **Nodes**: One per topical cluster. Size by relation count.
- **Color coding**:
  - Neutral gray: Shared territory (commodity claims from Step 4)
  - Red/coral: Competitor-owned territory (brand gaps from Step 5)
  - Green/teal: Brand-owned territory (defensive assets from Step 6)
  - Dashed border, muted fill: Unclaimed territory (white space from Step 7)
- **Edges**: Connect clusters that share entity relations.
- **Labels**: Cluster name inside or adjacent to each node.
- **Legend**: Color legend mapping each territory type.

Cap the diagram at the top 15-20 clusters. More than that becomes unreadable. This visualization appears inline before the detailed gap map tables. It serves as the executive summary visual.

### Step 9: Generate the gap map

```markdown
# Competitive Gap Map: [Brand] vs [Competitor Set]

**Brand URL**: [brand URL]
**Competitors analyzed**: [N URLs]
**Analysis scope**: [positioning / solution / content]
**Date**: [current date]

---

## Executive Summary

[3-5 bullets capturing the most actionable findings. Each bullet names a specific territory, the type (shared, competitor-owned, brand-owned, unclaimed), and the strategic implication.]

---

## 1. Shared Territory (Commodity Claims)

Positioning claims that exist across the brand and competitor field. Necessary for category coverage. Not differentiating.

| Cluster | Representative Relations | Frequency | Action |
|---|---|---|---|

**Implication**: Maintain coverage. Do not over-invest copy or content here.

---

## 2. Competitor-Owned Territory (Brand Gaps)

Entity relations the competitor field asserts that the brand does not.

| Cluster | Owned By (competitors) | Representative Relations | Strategic Fit | Recommended Action |
|---|---|---|---|---|

Strategic fit values:

- **High**: Directly relevant to ICP and capability. Claim it.
- **Medium**: Tangential but defensible. Test claiming it.
- **Low**: Off-brand or out of scope. Ignore.
- **Ambiguous**: Requires strategic discussion.

---

## 3. Brand-Owned Territory (Defensive Assets)

Entity relations the brand owns that competitors do not. Differentiation assets.

| Cluster | Representative Relations | Reinforcement Opportunities |
|---|---|---|

**Implication**: These are competitive moats. Reinforce in copy, content, and entity corroboration. Do not abandon in repositioning.

---

## 4. Unclaimed Territory (White Space)

Structural gaps in the competitor field that no brand currently owns.

| Cluster | Why Unclaimed | First-Mover Advantage | Recommended Action |
|---|---|---|---|

**Implication**: First brand to claim these owns the territory. Prioritize by strategic relevance and capability fit.

---

## 5. Field Topology Summary

| Metric | Brand | Competitor Field |
|---|---|---|
| Topical clusters | [N] | [N] |
| Unique entity relations | [N] | [N] |
| Shared relations | [N] | |
| Brand-only relations | [N] | |
| Competitor-only relations | | [N] |
| Field-level structural gaps | | [N] |

---

## 6. Interactive Graphs (if requested)

Explore the full network visualizations on KeywordGraph:

- **Brand positioning graph**: [KeywordGraph link from Step 3]
- **Merged competitor corpus**: [KeywordGraph link from Step 2]

Omit this section if the user did not request graph visuals.

---

## Recommended Next Steps

[3-5 prioritized actions:
- What to do
- Why (which gap or asset triggered it)
- Expected impact
- Urgency (this quarter / this year / backlog)]
```

### Step 10: Present output

Present the gap map inline in chat.

## Tool reference

| Tool | Step | Purpose |
|---|---|---|
| `firecrawl_scrape` | 1 | Pre-scrape all URLs before KeywordGraph analysis |
| `merged_graph_from_texts` | 2 | Build combined competitor corpus graph |
| `create_knowledge_graph` | 2, 3 | Persist graphs for interactive exploration |
| `analyze_text` | 3 | Build brand positioning graph |
| `overlap_between_texts` | 4 | Shared territory (commodity claims) |
| `difference_between_texts` | 5, 6 | Bidirectional gap detection |
| `visualize:show_widget` | 8 | Inline competitive territory diagram |

## Edge cases

- **Fewer than 3 competitor URLs**: Ask the user to provide more. With 2 or fewer, the merged corpus is unreliable. Pairwise `difference_between_texts` per competitor is the fallback, but the "field" view is lost.
- **Asymmetric URL types**: Brand homepage compared against competitor solution pages produces noise. Match URL types. If inputs are asymmetric, ask whether to adjust.
- **Thin brand content**: Under 500 words after Firecrawl scrape produces sparse graphs and weak differentials. Suggest analyzing a more substantive brand URL.
- **Firecrawl returns thin content for a known content-rich page**: The page likely relies on JS rendering. Retry with `waitFor: 5000` or `proxy: "stealth"` to capture dynamically loaded content.
- **Industry-specific jargon**: Technical niches may produce clusters that look incoherent at first glance. Read `mainConcepts` carefully. Clusters often capture meaningful patterns even when labels look strange.
- **Brand and competitors operate in different categories**: Low overlap is itself a finding. May indicate the brand is positioned in a different category. Can be a strategic strength or a category fit problem.
- **KeywordGraph unavailable**: This skill cannot run without it. Stop and notify the user that KeywordGraph is required. Do not attempt degraded methodology.
- **Firecrawl unavailable**: This skill cannot run without it. All content must be pre-scraped before KeywordGraph analysis. Stop and notify the user that Firecrawl is required.
- **`merged_graph_from_texts` timeout**: Fall back to individual `analyze_text` calls per scraped text. Manually aggregate clusters and relations. Note the degradation in the output.

## Voice and output rules

- No em dashes
- Tables for comparisons, prose for diagnosis
- The gap map is a strategic deliverable. It should read like a senior strategist's briefing.

## Failure modes to avoid

- Treating shared territory as a problem. Category coverage is table stakes.
- Recommending the brand claim every competitor-owned territory. Strategic fit matters.
- Ignoring defensive assets. These are moats. Identify and protect them.
- Producing generic "they should do more X" recommendations. Always tie to specific clusters and relations.
- Failing to flag asymmetric URL inputs. Apples to oranges produces unreliable maps.
- Skipping field-level structural gap analysis. White space opportunities are often the highest-leverage finding.
